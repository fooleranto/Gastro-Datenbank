Wichtige Informationen f�r Corona Gastronomie-Datenbank Version 1.0

Bei dem Programm handelt es sich um Freeware in jeder Hinsicht, kann
also ohne jegliche Einschr�nkung von Ihnen verwendet werden.

Sollte Ihnen das Programm gefallen, so k�nnen Sie mir gerne ein
Bierchen, oder einen Landkaffee spendieren. Dann programmiert
es sich leichter.

Hier mein Paypal-Account f�r die kleine Spende: gunterkoch@t-online.de